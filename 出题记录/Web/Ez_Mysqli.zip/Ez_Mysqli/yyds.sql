/*
 Navicat Premium Data Transfer

 Source Server         : flagflag
 Source Server Type    : MySQL
 Source Server Version : 80012
 Source Host           : localhost:3306
 Source Schema         : flagflag

 Target Server Type    : MySQL
 Target Server Version : 80012
 File Encoding         : 65001

 Date: 30/03/2021 10:08:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for yyds
-- ----------------------------
DROP TABLE IF EXISTS `yyds`;
CREATE TABLE `yyds`  (
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `yyds` VALUES ('yyds', 'yyds');
INSERT INTO `yyds` VALUES ('Y4tacker', 'flag{lalalala}');

SET FOREIGN_KEY_CHECKS = 1;
