<?php
highlight_file(__FILE__);
//flag在字段Y4tacker里
$servername = "localhost";
$username = "flagflag";
$password = "flagflag";
$dbname = "flagflag";
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,'utf8');
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
if(stripos($_GET['username'],'Y4tacker')!==false){
    die("爬");
}
else{
    $username=$_GET['username'];
}
if (strlen($username)>=11){
    die("爬");
}
if (preg_match("/,|#|-|\+|\'|\"|or|union|select|show|\\\\/im",$username)){
    die("爬");
}
$sql = "select * from `yyds` where username='$username'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
       echo($row['password']);
    }
}
$conn->close();
?>